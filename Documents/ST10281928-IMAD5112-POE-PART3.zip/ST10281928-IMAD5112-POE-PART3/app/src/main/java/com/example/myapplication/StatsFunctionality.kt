package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast


class StatsFunctionality : AppCompatActivity() {

    private var enteredNumber: TextView? = null
    private var arrayDisplay: TextView? = null
    private var answer: TextView? = null
    //Declaration of the array
    private var numberArray = IntArray(10)
    private var counter = 0



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats_functionality)

        enteredNumber = findViewById(R.id.edtNum)
        arrayDisplay = findViewById(R.id.tvStored)
        answer = findViewById(R.id.tvAnswer)

        val store = findViewById<Button>(R.id.btnStore)
        val average = findViewById<Button>(R.id.btnAvg)
        val minmax = findViewById<Button>(R.id.btnMinMax)
        val clear = findViewById<Button>(R.id.btnClear)
        val basic = findViewById<Button>(R.id.btnBasicCalc)

        store.setOnClickListener {
            storeNum()

        }
        average.setOnClickListener {
            avgCalc()
        }
        minmax.setOnClickListener {
            MinMax()
        }
        clear.setOnClickListener {
            delete()
        }
        //The code to navigate to the basic calculator
        basic.setOnClickListener {
            val intent = Intent(this,MainActivity ::class.java)
            startActivity(intent)
        }


    }

    private fun populated(): Boolean {

        // This is to make sure that the input box is not empty
        var b = true
        if (enteredNumber?.text.toString().trim().isEmpty()) {
            enteredNumber?.error = "Required"
            b = false
        }
        return b
    }

    private fun updateRow(){
        val displayNum = numberArray.copyOfRange(0,counter)

        arrayDisplay?.text = " ${displayNum.joinToString(",","")}"
    }

    private fun storeNum(){
        if (populated()){

            var number = enteredNumber?.text.toString().trim().toInt()

            if (counter<numberArray.size){
                numberArray[counter] = number
                counter ++
                arrayDisplay?.text ="Value${enteredNumber?.text.toString().trim().toInt()} saved \n "
                updateRow()
                enteredNumber?.text = ""


            }else{
               arrayDisplay?.text ="Array full"
                enteredNumber?.text = ""
            }
        }
    }

    private fun avgCalc(){

            var total = 0.0

            for (num in numberArray){
                // This will add all the numbers of the array to get the total
                total += num
            }

            val avg = total / numberArray.size
            answer?.text = "Average is $avg"

    }

    private fun MinMax(){


            //This equates the first position of the array to the variable

            var currentMax = numberArray[0]
            var currentMin = numberArray[0]

            for ( i in 1 until  counter){
                if (numberArray[i] < currentMin){
                    currentMin = numberArray[i]
                }
                if (numberArray[i] > currentMax){
                   currentMax = numberArray[i]
                }
            }
            answer?.text = "Max: $currentMax \n Min: $currentMin"

    }

    private fun delete(){

            //This is the for loop to clear the array, this will make every position equal to 0
            for (i in 0 until numberArray.size){
               numberArray[i] = 0
            }
            counter=0
            arrayDisplay?.text = "Array is empty"

    }

}