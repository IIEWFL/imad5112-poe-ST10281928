package com.example.myapplication

import android.content.Intent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.math.RoundingMode
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private var numberOne: TextView? = null
    private var numberTwo: TextView? = null
    private var output: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        numberOne = findViewById(R.id.firstNumber)
        numberTwo = findViewById(R.id.secondNumber)
        output = findViewById(R.id.tvAnswer)


        val add = findViewById<Button>(R.id.btnAddition)
        val minus = findViewById<Button>(R.id.btnSubtract)
        val multiply = findViewById<Button>(R.id.btnMultiply)
        val divide = findViewById<Button>(R.id.btnDivide)
        val sqrRoot = findViewById<Button>(R.id.btnsqrRoot)
        val power = findViewById<Button>(R.id.btnPower)
        val stats = findViewById<Button>(R.id.btnStats)


        add.setOnClickListener {
            add()
        }
        minus.setOnClickListener {
            subtract()
        }
        multiply.setOnClickListener {
            multiply()
        }
        divide.setOnClickListener {
            divide()
        }
        sqrRoot.setOnClickListener {
            squareRoot()
        }
        power.setOnClickListener {
            exponent()
        }
        stats.setOnClickListener {
          val intent = Intent(this,StatsFunctionality::class.java)
            startActivity(intent)
        }
    }

    private fun add() {

        if (populated()) {

            val insert1 = numberOne?.text.toString().trim().toBigDecimal()
            val insert2 = numberTwo?.text.toString().trim().toBigDecimal()
            val answer = insert1.add(insert2).toString()
            output?.text = "$insert1 + $insert2 = $answer"
        }
    }

    //This if-statement is to determine whether the input is empty or not
    private fun populated(): Boolean {

        var b = true
        if (numberOne?.text.toString().trim().isEmpty()) {
            numberOne?.error = "Required"
            b = false
        }
        if (numberTwo?.text.toString().trim().isEmpty()) {
            numberTwo?.error = "Required"
            b = false
        }
        return b
    }

    private fun subtract() {

        if (populated()) {

            val insert1 = numberOne?.text.toString().trim().toBigDecimal()
            val insert2 = numberTwo?.text.toString().trim().toBigDecimal()
            val answer = insert1.subtract(insert2).toString()
            output?.text = "$insert1 - $insert2 = $answer"
        }
    }

    private fun multiply() {

        if (populated()) {

            val insert1 = numberOne?.text.toString().trim().toBigDecimal()
            val insert2 = numberTwo?.text.toString().trim().toBigDecimal()
            val answer = insert1.multiply(insert2).toString()
            output?.text = "$insert1 x $insert2 = $answer"
        }
    }

    private fun divide() {

        if (populated() && notZero()) {

            val insert1 = numberOne?.text.toString().trim().toBigDecimal()
            val insert2 = numberTwo?.text.toString().trim().toBigDecimal()
            val answer = insert1.divide(insert2, 7, RoundingMode.HALF_UP).toString()
            output?.text = "$insert1 / $insert2 = $answer"
        }
    }

    //This will determine if the input is Zero or not
    private fun notZero(): Boolean {
        var c = true

        val insert1 = numberOne?.text.toString().trim().toInt()
        val insert2 = numberTwo?.text.toString().trim().toInt()

        if (insert1 == 0 || insert2 == 0) {
            output?.text = "Please enter a number bigger than zero"
            c = false
        }
        return c
    }

    private fun squareRoot() {

        if (populated()) {

            val insert1 = numberOne?.text.toString().trim().toDouble()
            val insert2 = numberTwo?.text.toString().trim().toDouble()

            //These if-statements are to determine if the answer of a root need and "i" symbol or not
            if (insert1 < 0 || insert1 > 0) {

                //Each one of the statements will determine for every scenario
                if (insert1 < 0 && insert2 < 0) {
                    var result = sqrt(-insert1)
                    var result2 = sqrt(-insert2)
                    output?.text = "sqrt($insert1)= $result i and \n sqrt($insert2)= $result2 i"
                } else
                    if (insert1 < 0 && insert2 > 0) {
                        var result = sqrt(-insert1)
                        var result2 = sqrt(insert2)
                        output?.text = "sqr$insert1 = $result i and \n sqr$insert2= $result2"
                    } else
                        if (insert2 < 0 && insert1 > 0) {
                            var result = sqrt(insert1)
                            var result2 = sqrt(-insert2)
                            output?.text = "sqr$insert1 = $result  and \n sqr$insert2= $result2 i"
                        } else
                            if (insert1 > 0 && insert2 > 0) {
                                var result = sqrt(insert1)
                                var result2 = sqrt(insert2)
                                output?.text =
                                    "sqr$insert1 = $result  and \n sqr$insert2= $result2 "
                            }
            }


        }
    }

    private fun exponent() {

        if (populated()) {
            val insert1 = numberOne?.text.toString().trim().toBigDecimal()
            val insert2 = numberTwo?.text.toString().trim().toBigDecimal()
            // This is the variable that will store the answer until the loop is done
            var result = 1.0

            for (i in 1..insert2.toInt()) {
                //The variable results will multiply itself with input one until the limit is reached
                result *= insert1.toInt()
            }
            output?.text = "$insert1 ^ $insert2 = $result"
        }
    }



}
